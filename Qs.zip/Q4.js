//Ahmad Jajja WEB&MOBILE APP CERTIFIED
//Famous Quote: Find a quote from a famous person you admire. Print the quote and the name of its author. Your output should look 

console.log(`Albert Einstein once said, “A person who never made a mistake never tried anything new.”`);