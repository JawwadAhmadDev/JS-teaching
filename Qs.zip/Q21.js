//Ahmad Jajja WEB&MOBILE APP CERTIFIED
//They think of something you could store in a JavaScript Object. Write a program that creates Objects containing these items.


const personalDetail = {
    name: "ahmad",
    class: "BSCS",
    skills: "Full Stack Developer",
    certifications: "WEB and MOBILE APP CERTIFIED"
}

console.log("Personal detail => ", personalDetail)