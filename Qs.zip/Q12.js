//Ahmad Jajja WEB&MOBILE APP CERTIFIED
//Greetings: Start with the array you used in Exercise 11, but instead of just printing each person’s name, print a message to them. The text of each message should be the same, but each message should be personalized with the person’s name.

var friendsName = ["Ahmad", "Abuhurairah", "Hamza"];
for (let index = 0; index < friendsName.length; index++) {
    console.log("My friend name is => ",friendsName[index]);
}