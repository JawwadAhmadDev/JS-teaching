//Ahmad Jajja WEB&MOBILE APP CERTIFIED
//Personal Message: Store a person’s name in a variable, and print a message to that person. Your message should be simple, such as, “Hello Eric, would you like to learn some Python today?
var message = "Hello Ahmad, would you like to learn some Python today?";
console.log("message => " , message);