//Ahmad Jajja WEB&MOBILE APP CERTIFIED
// Conditional Tests: Write a series of conditional tests. Print a statement describing each test and your prediction for the results of each test. Your code should look something like this:

// let car = 'subaru';

// console.log("Is car == 'subaru'? I predict True.")

// console.log(car == 'subaru')

// • Look closely at your results, and make sure you understand why each line evaluates to True or False.



//portion 1
// Look closely at your results, and make sure you understand why each line evaluates to True or False.


let car = "subaru";

 if (car = 'subaru') {
    console.log("I predict True.")
 } else {
    console.log("I predict false.") 
 }


// portion 2
// Create at least 10 tests. Have at least 5 tests evaluate to True and another 5 tests evaluate to False.
//1 comparison
if (5 === "ahmad".length) {
    console.log("I predict True.")
} else {
    console.log("I predict false.") 
 }
//2 comparison

if (1 === "ahmad".indexOf("h")) {
    console.log("I predict True.")
} else {
    console.log("I predict false.") 
 }
//3 comparison

if ("ahmad" === "ahmad".toLowerCase()) {
    console.log("I predict True.")
} else {
    console.log("I predict false.") 
 }
//4 comparison

if ("ahmad" === "ahmad".trim()) {
    console.log("I predict True.")
} else {
    console.log("I predict false.") 
 }

//5 comparison

if ('d' === "ahmad".charAt(4)) {
    console.log("I predict True.")
} else {
    console.log("I predict false.") 
 }

 //6 comparison

if (1 != "ahmad".indexOf("h")) {
    console.log("I predict true")
} else {
    console.log("I predict false.") 
 }

//7 comparison

 if (1 != "ahmad".indexOf("h")) {
    console.log("I predict True.")
} else {
    console.log("I predict false.") 
 }

 //8 comparison

if ("ahmad" != "ahmad".toLowerCase()) {
    console.log("I predict True.")
} else {
    console.log("I predict false.") 
 }

//9 comparison

if ("ahmad" != "ahmad".trim()) {
    console.log("I predict True.")
} else {
    console.log("I predict false.") 
 }

 //10 comparison

if ('d' != "ahmad".charAt(4)) {
    console.log("I predict True.")
} else {
    console.log("I predict false.") 
 }


 























