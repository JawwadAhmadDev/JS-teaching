//Ahmad Jajja WEB&MOBILE APP CERTIFIED
//Think of something you could store in a array. For example, you could make a list of mountains, rivers, countries, cities, languages, or anything else you’d like. Write a program that creates a list containing these items.


const countries = ["Pakistan", "India", "Afghanistan", "Bangledesh", "Srilanka"];

console.log("list of countries is => ", countries);