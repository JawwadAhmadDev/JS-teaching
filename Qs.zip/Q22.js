//Ahmad Jajja WEB&MOBILE APP CERTIFIED
//Intentional Error: If you haven’t received an array index error in one of your programs yet, try to make one happen. Change an index in one of your programs to produce an index error. Make sure you correct the error before closing the program.


const countries = ["Pakistan", "India", "Afghanistan", "Bangledesh", "Srilanka"];

console.log("Intentional Index Error:", countries[10])

console.log("Output without international error of countries[3]=>", countries[3])