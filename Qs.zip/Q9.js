//Ahmad Jajja WEB&MOBILE APP CERTIFIED
//Favorite Number: Store your favorite number in a variable. Then, using that variable, create a message that reveals your favorite number. Print that message.

var favoriteNumber = 8;
var message = `my favourite number is ${favoriteNumber}`;

console.log("message => ", message)

