//Ahmad Jajja WEB&MOBILE APP CERTIFIED
//Dinner Guests: Working with one of the programs from Exercises 14 through 18, print a message indicating the number of people you are inviting to dinner.

var guests = ["anyone", "living"];

console.log("letting them know you’re still invited.")

for (let index = 0; index < guests.length; index++) {
    const element = guests[index];
    console.log(element)
    
}

console.log(`According to QS 17 second portion the number of guest are  ${guests.length}`);