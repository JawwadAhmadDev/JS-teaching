//Famous Quote: Find a quote from a famous person you admire. Print the quote and the name of its author. Your output should look
  
var personName = "\tAhmad jajja\n";
console.log("personName with white spaces =>", personName)
personName = "Ahmad jajja";
console.log("personName without white spaces =>", personName)