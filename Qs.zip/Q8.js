//Ahmad Jajja WEB&MOBILE APP CERTIFIED
//You should create four lines that look like this:

console.log("____________________________________ \n",5+8,"\n____________________________________");