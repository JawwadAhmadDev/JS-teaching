//Ahmad Jajja WEB&MOBILE APP CERTIFIED
// Large Shirts: Modify the make_shirt() function so that shirts are large by default with a message that reads I love JavaScript. Make a large shirt and a medium shirt with the default message, and a shirt of any size with a different message.



const make_shirt = (size, text) =>  {
    console.log(`${size}`)
    console.log(`${text}`);
}

make_shirt("Large ", "I love javascript");
make_shirt("Medium ", "who is u? i am a coder!");



